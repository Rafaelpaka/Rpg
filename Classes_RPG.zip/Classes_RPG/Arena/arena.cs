using  System.Collections.Generic;
using System.Linq;
using Entidade;

namespace arena;
public class Arena
{
    List<Entities>Arena = new List<Entities>();
}