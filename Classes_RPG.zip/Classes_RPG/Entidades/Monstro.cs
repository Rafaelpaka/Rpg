namespace Entidade;

public class Monstro : Entidade
{
    public Monstro(string nome, int vida, int ataque) : base(nome, vida, ataque)
    {
        nome = "Monstro";
        vida = 100 + 20*Nivel;
        ataque = 5;
        DanoVeneno = 1 + (0,2 * Nivel);
        Turnosdoveneno = 2;
        
        


    }


}