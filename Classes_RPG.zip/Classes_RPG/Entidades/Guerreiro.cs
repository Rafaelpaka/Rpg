
namespace Entidade;
public class Guerreiro : Entidades
{
    public Guerreiro(string nome, int vida, int Nivel) : base(nome, vida, Nivel)
    {
        nome = "Guerreiro";
        Ataque = 15 + (5 * Nivel);
        vida = 200 + (10 * Nivel);


    }



}