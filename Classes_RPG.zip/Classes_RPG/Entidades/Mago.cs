namespace Entidade;
public class Mago : Entidades
{
    public int Inteligencia => Nivel * 2;
    public Mago(string nome, int nivel, int ataque) : base(nome, nivel, ataque)
    {
        nome = "Mago";
        Vida = 100 + (Nivel * 10);
        ChanceCritico = 5 + 0.5*(Inteligencia * 2);
        Random random = new Random();
        ataque = 10;
        int FoiCritico = random.Next(100);
        if (FoiCritico < ChanceCritico)
        {
            ataque *= 2;
        }
    }
}