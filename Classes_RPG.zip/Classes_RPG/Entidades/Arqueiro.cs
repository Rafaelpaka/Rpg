namespace Entidade;

public class Arqueiro : Entidades
{
    public Arqueiro(string nome, int vida, int Nivel) : base(nome, vida, Nivel)
    {
        ome = "Arqueiro";
        Random random = new Random();
        vida = 125;
        Dano = 15;
        int ChanceEsquivar = 10 + (Nivel * 4);
    }
}