namespace Entidade;

public class Entidade
{
    public string Nome{get; set;} = string.Empty;
    public int Vida{get;private set;} = 100;
    public int Nivel{get; set;}
    public int Ataque{get; set;}
    public bool Morte{get; set;} = false;
    public int DanoTotalCausado{get; set;} = 0;

    public void VidaIncicial(int VidaIncicial)
    {
        Vida = VidaIncicial;
    }
}