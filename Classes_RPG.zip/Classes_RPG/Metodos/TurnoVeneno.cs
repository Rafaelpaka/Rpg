using Entidade;


namespace Metodos;
public class TurnoVeneno
{
    public void Veneno(Monstro Monstro,Entidade Alvo)
    {
        if (Monstro.Veneno == true)
        {
            Alvo.Vida -= Monstro.DanoVeneno;
            break;
            Console.WriteLine($"O {Monstro.Nome} causou {Monstro.DanoVeneno} de dano de veneno em {Alvo.Nome}");
        }
           
        
    }
}