namespace Metodos;
public class Cura
{
    public void curar(Entidade alvo)
    {
        Console.WriteLine($"Curando {alvo.Nome}");
        alvo.vida += 50;
    }
}