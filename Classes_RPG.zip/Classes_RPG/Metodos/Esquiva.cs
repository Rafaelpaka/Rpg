using Entidade;

public class Esquiva
{
    public void ChanceEsquivar(Arqueiro arqueiro, int ChanceEsquivar){

        int Esquivou = random.Next(100);
        if (Esquivou <= ChanceEsquivar)
        {
            Console.WriteLine("O Arqueiro esquivou do ataque!");
            return 1;
        }
        else
        {
            Console.WriteLine("O Arqueiro não conseguiu esquivar!");
            return 0;
        }

}
}