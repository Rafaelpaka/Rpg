// fazer um contador para o monstro que a cada round diminui para a utilização do veneno, fora isso tudo normal
using Entitdade;


namespace metodos;
public class atacar()
{
    public void Ataque(Entidade agressor, Entidade Vitima, Turnosdoveneno duracao)
    {
        TurnoVeneno LigicaVeneno = new TurnoVeneno();

        Console.WriteLine($"{agressor.Nome} atacou {Vitima.Nome} com {agressor.Ataque} de dano");
        
        if (Vitima.Vida > 0)
            if (agressor.nome == "Mago")
            {
                ChanceCritico = 5 + 0.5*(Inteligencia * 2);
                Random random = new Random();
                ataque = 10;
                int FoiCritico = random.Next(100);
                if (FoiCritico < ChanceCritico)
                {
                    ataque *= 2;
                }
            }



        {   if (agressor.nome == "Monstro" &&  duracao.turnoVeneno > 0)
            {
                
                LogicaVeneno.TurnoVeneno(agressor, Vitima);
                duracao.turnoVeneno -= 1;

            }



            Vitima.Vida -= agressor.Ataque;
        }


    }


}