using Entidade;

namespace Metodos;

public class ReceberDano()
{
    ChanceEsquiva chance = new ChanceEsquiva();
    public void CalculoDano(Entidade alvo)
    {   if (alvo.Nome == "Arqueiro")
        {
            ChanceEsquiva == 1;
            COnsole.WriteLine("O Arqueiro Esquivou");
            return alvo.Vida;
        }
        alvo.Vida = Entidade.Ataque - alvo.Vida;
        return alvo.Vida;

    }
}


